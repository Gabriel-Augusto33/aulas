# Trabalho — Áreas do Conhecimento

## Como abrir no VS Code
1. Extraia a pasta `atividade_areas_conhecimento`.
2. No VS Code, clique em **File > Open Folder** (Arquivo > Abrir Pasta) e selecione essa pasta.
3. Abra `index.html`. Para visualizar, use a extensão **Live Server** (opcional) ou abra o arquivo no navegador.

## Publicar no GitHub
1. Crie um repositório novo no https://github.com.
2. Escolha **Add file > Upload files** e envie todos os arquivos desta pasta.
3. Confirme em **Commit changes**.
4. Para publicar como site, entre em **Settings > Pages**, selecione a branch `main` e a pasta `/ (root)`, e salve.
5. Aguarde a publicação e abra o endereço indicado pelo GitHub Pages.

Personalize as reflexões para que correspondam à sua experiência real.
